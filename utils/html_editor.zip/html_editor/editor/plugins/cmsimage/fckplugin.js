﻿/*
 * FCKeditor - The text editor for internet
 * Copyright (C) 2003-2006 Frederico Caldeira Knabben
 * 
 * Licensed under the terms of the GNU Lesser General Public License:
 * 		http://www.opensource.org/licenses/lgpl-license.php
 * 
 * For further information visit:
 * 		http://www.fckeditor.net/
 * 
 * "Support Open Source software. What about a donation today?"
 * 
 * File Name: fckplugin.js
 * 	Plugin to insert "Popuplinks" in the editor.
 * 
 * File Authors:
 * 		Frederico Caldeira Knabben (fredck@fckeditor.net)
 */

// Register the related command.
FCKCommands.RegisterCommand( 'CMSImage', new FCKDialogCommand( 'CMSImage', 'Add/Edit Image', FCKPlugins.Items['cmsimage'].Path + 'fck_cmsimage.html', 450, 450 ) ) ;

// Create the "Plaholder" toolbar button.
var oCMSImageItem = new FCKToolbarButton( 'CMSImage', FCKLang.CMSImageBtn ) ;
oCMSImageItem.IconPath = FCKPlugins.Items['cmsimage'].Path + 'cmsimage.gif' ;

FCKToolbarItems.RegisterItem( 'CMSImage', oCMSImageItem ) ;

FCK.ContextMenu.RegisterListener( {
        AddItems : function( menu, tag, tagName )
        {
                // under what circumstances do we display this option
                if ( tagName == 'IMG' )
                {
                        // when the option is displayed, show a separator  the command
                        menu.AddSeparator() ;
                        // the command needs the registered command name, the title for the context menu, and the icon path
                        menu.AddItem( 'CMSImage', 'Image Properties', oCMSImageItem.IconPath ) ;
                }
        }}
);


